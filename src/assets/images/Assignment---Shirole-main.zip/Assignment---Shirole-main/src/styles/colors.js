// styles/colors.js

export const COLORS = {
    primary: '#3DB6FB', 
    secondary: '#007bff', 
    text: '#333', 
    background: '#f4f4f4', 
    
  };
  
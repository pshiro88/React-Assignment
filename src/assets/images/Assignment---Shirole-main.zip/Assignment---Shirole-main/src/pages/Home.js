import React from 'react'
import Navbar from '../components/navbar';
import Header from '../components/header';
import Hero from '../components/hero';
import OverView from '../components/overview';


export default function Home() {
  return (
    <>
    <Header />
    <Navbar/>
    <Hero />
    <OverView/>
    
  </>
  )
}
